# NODRIVER

## for docs click [here](https://ultrafunkamsterdam.github.io/nodriver)

## Credit
All credit to the original repository and creator https://github.com/ultrafunkamsterdam/nodriver. This fork was created 
so that I could better incorporate nodriver into my projects.

## Changes

- Added timed query selectors to match the find calls to allow for waiting for page loading when using query selectors
- Element.text_all now returns an array for each node so that you can differentiate between text from different nodes